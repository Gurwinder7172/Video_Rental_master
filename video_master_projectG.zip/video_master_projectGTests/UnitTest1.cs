﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using video_master_projectG;
namespace video_master_projectG
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            Video instance = new Video();
            int cost=instance.generateCost(2019);
            if (cost == 5)
            {
                Assert.IsTrue(true);
            }
            else {
                Assert.IsTrue(false);
            }



        }

        [TestMethod]
        public void TestInsertMethod1()
        {

            Video instance = new Video();
            instance.Insert_Video("insert into Movie values ('Hum','2.4',1990,5,2,'ok','good')");
            Assert.IsTrue(true);


        }

    }
}
