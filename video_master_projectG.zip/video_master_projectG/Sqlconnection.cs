﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace video_master_projectG
{
     public class Sqlconnection
    {
        //object of the sqlconnection class that is used to connect to with the sql server management 
        SqlConnection sqlcntn;

        //object of the sqlcommand class that is used to connect to with the sql server management 
        SqlCommand sqlcmd;

        //object of the sqlDataReader class that is used to connect to with the sql server management
        SqlDataReader sqlDataReader;


        //connection string of the class
        String location = "Data Source=DESKTOP-G2UGPMF\\SQLEXPRESS;Initial Catalog=VideoProject;Integrated Security=True";



        //to perform the dml operation like insert delete or update 
        public void SqlOperation(String query)
        {
            sqlcntn = new SqlConnection(location);
            sqlcntn.Open();
            sqlcmd = new SqlCommand(query, sqlcntn);
            sqlcmd.ExecuteNonQuery();
            sqlcntn.Close();
        }

        //get to carry the data from sql server data base and pass to data table 
        public DataTable searchOperation(String qry)
        {
            DataTable tbl = new DataTable();

            sqlcntn = new SqlConnection(location);

            sqlcntn.Open();

            sqlcmd = new SqlCommand(qry, sqlcntn);

            sqlDataReader = sqlcmd.ExecuteReader();

            tbl.Load(sqlDataReader);

            sqlcntn.Close();

            return tbl;
        }



    }
}
