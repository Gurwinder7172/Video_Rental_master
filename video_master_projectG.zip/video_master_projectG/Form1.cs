﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace video_master_projectG
{
    public partial class Form1 : Form
    {

        Client instance_client = new Client();

        Video instance_video = new Video();

        //global variable 
        int BookingId = 0;

        String details = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void add_custo_Click(object sender, EventArgs e)
        {
            // get the data and validate to check and pass
            if (cust_name.Text.ToString().Equals("") && cust_name.Text.ToString().Equals("") && cust_name.Text.ToString().Equals("")) {
                MessageBox.Show("Fill all the details ");
            }
            else {
                instance_client.add_Customer(cust_name.Text,cust_email.Text,cust_city.Text);
                MessageBox.Show("Client is registered now you can book movie on rent ");
            }

            //reset the elements 
            cust_name.Text = "";
            cust_email.Text = "";
            cust_city.Text = "";

        }

        private void delete_cust_Click(object sender, EventArgs e)
        {
            // get the id to delete the customer only can delete the data if he has no booking 
            if (cust_id.Text.ToString().Equals("")) {
                MessageBox.Show("Select the Customer to delete ");
            }
            else {
                if (instance_client.delete_Customer(Convert.ToInt32(cust_id.Text.ToString())))
                {
                    MessageBox.Show("Client is removed ");
                }
                else {
                    MessageBox.Show("client already have movie ");
                }
            }
            
            //reset the elements 
            cust_name.Text = "";
            cust_email.Text = "";
            cust_city.Text = "";
            cust_id.Text = "";

        }

        private void update_custo_Click(object sender, EventArgs e)
        {
            // get the data and validate to check and pass
            if (cust_id.Text.ToString().Equals("") && cust_name.Text.ToString().Equals("") && cust_name.Text.ToString().Equals("") && cust_name.Text.ToString().Equals(""))
            {
                MessageBox.Show("Fill all the details ");
            }
            else
            {
                instance_client.updtae_Customer(Convert.ToInt32(cust_id.Text.ToString()),cust_name.Text, cust_email.Text, cust_city.Text);
                MessageBox.Show("Client details are updated ");
            }

            //reset the elements 
            cust_name.Text = "";
            cust_email.Text = "";
            cust_city.Text = "";


        }
        //for adding video 
        private void add_video_Click(object sender, EventArgs e)
        {
            if (movie_name.Text.ToString().Equals("")&& movie_plot.Text.ToString().Equals("") && movie_year.Text.ToString().Equals("") && movie_rates.Text.ToString().Equals("") && movie_copy.Text.ToString().Equals("") && movie_genre.Text.ToString().Equals("")) {
                MessageBox.Show("must provide all the info ");
            }
            else {

                int cst =instance_video.generateCost(Convert.ToInt32(movie_year.Text.ToString()));

                String insert = "insert into Movie values('"+movie_name.Text.ToString()+"','"+movie_rates.Text.ToString()+"',"+Convert.ToInt32(movie_year.Text.ToString())+","+ Convert.ToInt32(movie_copy.Text.ToString()) + ","+cst+",'"+movie_plot.Text.ToString()+"','"+movie_genre.Text.ToString()+"')";
                instance_video.Insert_Video(insert);
                MessageBox.Show("video is stored ");



            }

            //reset the all varaible from the form 
            movie_copy.Text = "";
            movie_genre.Text = "";
            movie_name.Text = "";

            movie_plot.Text = "";
            movie_rates.Text = "";
            movie_year.Text = "";

        }

        private void delete_movie_Click(object sender, EventArgs e)
        {
            if (id_movie.Text.ToString().Equals(""))
            {
                MessageBox.Show("select the movie to delete ");
            }
            else {
                if (instance_video.delete_Video("delete from Movie where Movie_ID=" + Convert.ToInt32(id_movie.Text.ToString()) + "", Convert.ToInt32(id_movie.Text.ToString())))
                {
                    MessageBox.Show("record is deleted ");
                }
                else {
                    MessageBox.Show("Movie is on booking ");
                }
            }
            //reset the all varaible from the form 
            movie_copy.Text = "";
            movie_genre.Text = "";
            movie_name.Text = "";

            movie_plot.Text = "";
            movie_rates.Text = "";
            movie_year.Text = "";

            id_movie.Text = "";



        }

        private void update_movie_Click(object sender, EventArgs e)
        {
            if (movie_name.Text.ToString().Equals("") && movie_plot.Text.ToString().Equals("") && movie_year.Text.ToString().Equals("") && movie_rates.Text.ToString().Equals("") && movie_copy.Text.ToString().Equals("") && movie_genre.Text.ToString().Equals(""))
            {
                MessageBox.Show("must provide all the info ");
            }
            else
            {

                int cst = instance_video.generateCost(Convert.ToInt32(movie_year.Text.ToString()));

                String insert = "update Movie set Name='" + movie_name.Text.ToString() + "',Ratting='" + movie_rates.Text.ToString() + "',Year=" + Convert.ToInt32(movie_year.Text.ToString()) + ",Copies=" + Convert.ToInt32(movie_copy.Text.ToString()) + ",Cost=" + cst + ",Plot='" + movie_plot.Text.ToString() + "',Genre='" + movie_genre.Text.ToString() + "' where  Movie_ID=" + Convert.ToInt32(id_movie.Text.ToString()) + "";
                instance_video.Insert_Video(insert);
                MessageBox.Show("video is stored ");



            }
            //reset the all varaible from the form 

            movie_copy.Text = "";
            movie_genre.Text = "";
            movie_name.Text = "";

            movie_plot.Text = "";
            movie_rates.Text = "";
            movie_year.Text = "";
            id_movie.Text = "";


        }

        private void delete_rental_Click(object sender, EventArgs e)
        {
            if (BookingId == 0)
            {
                MessageBox.Show("select the Booking video to delete ");
            }
            else {
                // if a invalid entry is record in the database then we easily delete 
                instance_video.SqlOperation("delete from Booking where Rent_ID="+BookingId+"");
                MessageBox.Show("delete the Invalid Booking from record ");
            }

            //reset the all varaible from the form 
            movie_copy.Text = "";
            movie_genre.Text = "";
            movie_name.Text = "";

            movie_plot.Text = "";
            movie_rates.Text = "";
            movie_year.Text = "";
            id_movie.Text = "";


            cust_city.Text = "";
            cust_email.Text = "";
            cust_name.Text = "";
            cust_id.Text = "";

            BookingId = 0;

               
        }

        private void return_rent_Click(object sender, EventArgs e)
        {
            // generate the cost of the booking when the client came to return 
            if (BookingId == 0 && cust_id.Text.ToString().Equals("") && id_movie.Text.ToString().Equals(""))
            {
                MessageBox.Show("select  the booked video to return ");
            }
            else {

                //get the difference in days between 2 dates and get  the cost from the database 

                String diff2 = (EndDate.Value - strtDate.Value).TotalDays.ToString();
                //convert the string value to double 
                double d = Convert.ToDouble(diff2);
                //pass the roud off value to calculate 
                double days = Math.Round(d);

                //get the cost of the video 
                DataTable tbl = new DataTable();
                tbl = instance_video.searchOperation("select *  from  Movie where Movie_ID="+Convert.ToInt32(id_movie.Text.ToString())+"");

                int cost = Convert.ToInt32(tbl.Rows[0]["Cost"].ToString());

                int payment = Convert.ToInt32(days) * cost;


                String retrn = "update Booking set Movie_ID="+Convert.ToInt32(id_movie.Text.ToString())+", Customer_ID="+Convert.ToInt32(cust_id.Text.ToString())+",StartDate='"+strtDate.Text+"', EndDate='"+EndDate.Text+"' where Rent_ID="+BookingId+"";
                instance_video.SqlOperation(retrn);
                MessageBox.Show("Thanks for the Booking Your Payment is " + payment+" NZ Dollar");

            }

            //reset the all varaible from the form 
            movie_copy.Text = "";
            movie_genre.Text = "";
            movie_name.Text = "";

            movie_plot.Text = "";
            movie_rates.Text = "";
            movie_year.Text = "";
            id_movie.Text = "";


            cust_city.Text = "";
            cust_email.Text = "";
            cust_name.Text = "";
            cust_id.Text = "";

            BookingId = 0;


        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void issue_rent_Click(object sender, EventArgs e)
        {
            if (id_movie.Text.ToString().Equals("") && cust_id.Text.ToString().Equals("")) {
                MessageBox.Show("choose the client and movie to book ");
            }
            else {

                // for the booking we must check the details of the movie and client before booking 
                //confirm how much video is lready on booking from the database 
                DataTable tblBooking = new DataTable();
                tblBooking = instance_video.searchOperation("select * from Booking where Movie_ID="+Convert.ToInt32(id_movie.Text.ToString())+" and EndDate='Book'");
                int count = tblBooking.Rows.Count;
                if (count < Convert.ToInt32(movie_copy.Text.ToString()))
                {
                    DataTable tblCustomer= new DataTable();
                    tblCustomer = instance_video.searchOperation("select * from Booking where Customer_ID=" + Convert.ToInt32(cust_id.Text.ToString()) + " and EndDate='Book'");
                    int Customercount = tblCustomer.Rows.Count;
                    //check the customer how much video is has on rent 
                    if (Customercount==2) {
                        MessageBox.Show("this client can't book more movie");
                    }
                    else {
                        instance_video.SqlOperation("insert into Booking values("+Convert.ToInt32(id_movie.Text.ToString())+","+Convert.ToInt32(cust_id.Text.ToString())+",'"+strtDate.Text.ToString()+"','Book')");
                        MessageBox.Show("Movie is issued on Booking ");
                    }

                }
                else {
                    MessageBox.Show("We have no more copies ");
                }
                    
            }

            //reset the all varaible from the form 
            movie_copy.Text = "";
            movie_genre.Text = "";
            movie_name.Text = "";

            movie_plot.Text = "";
            movie_rates.Text = "";
            movie_year.Text = "";
            id_movie.Text = "";


            cust_city.Text = "";
            cust_email.Text = "";
            cust_name.Text = "";
            cust_id.Text = "";

            BookingId = 0;



        }

        // 

        private void st_movie_Click(object sender, EventArgs e)
        {
            DataTable storeTable = new DataTable();
            storeTable = instance_video.searchOperation("select * from Movie");
            tableRecord.DataSource = storeTable;
            details = "movie";
        }
        //selecting data from custmer form
        private void st_cust_Click(object sender, EventArgs e)
        {
            DataTable storeTable = new DataTable();
            storeTable = instance_video.searchOperation("select * from Customer");
            tableRecord.DataSource = storeTable;
            details = "customer";
        }
        //selecting rental data
        private void st_rental_Click(object sender, EventArgs e)
        {
            DataTable storeTable = new DataTable();
            storeTable = instance_video.searchOperation("select * from Booking");
            tableRecord.DataSource = storeTable;
            details = "booking";
        }

        // click we click on record on data table

        private void tableRecord_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (details.Equals("booking"))
            {
                BookingId = Convert.ToInt32(tableRecord.CurrentRow.Cells[0].Value);
                id_movie.Text = tableRecord.CurrentRow.Cells[1].Value.ToString();
                cust_id.Text = tableRecord.CurrentRow.Cells[2].Value.ToString();
                strtDate.Text = tableRecord.CurrentRow.Cells[3].Value.ToString();
            }
            else if (details.Equals("customer"))
            {
                cust_id.Text = tableRecord.CurrentRow.Cells[0].Value.ToString();
                cust_name.Text = tableRecord.CurrentRow.Cells[1].Value.ToString();
                cust_email.Text = tableRecord.CurrentRow.Cells[2].Value.ToString();
                cust_city.Text = tableRecord.CurrentRow.Cells[3].Value.ToString();
            }
            else if (details.Equals("movie"))
            {
                id_movie.Text = tableRecord.CurrentRow.Cells[0].Value.ToString();
                movie_name.Text = tableRecord.CurrentRow.Cells[1].Value.ToString();
                movie_rates.Text = tableRecord.CurrentRow.Cells[2].Value.ToString();
                movie_year.Text = tableRecord.CurrentRow.Cells[3].Value.ToString();
                movie_copy.Text = tableRecord.CurrentRow.Cells[4].Value.ToString();
                movie_plot.Text = tableRecord.CurrentRow.Cells[6].Value.ToString();
                movie_genre.Text = tableRecord.CurrentRow.Cells[7].Value.ToString();
            }
            else {
                MessageBox.Show("select the data first ");
            }

            tableRecord.DataSource = "";
            details = "";
        }

        // popular movie from database compared  
        private void pop_movie_Click(object sender, EventArgs e)
        {
            DataTable tblData = new DataTable();
            tblData = instance_video.searchOperation("select * from Movie");
            int x = 0, y = 0, cunt = 0;
            String Name= "";
            for (x = 0; x < tblData.Rows.Count; x++)
            {
                DataTable tbl = new DataTable();
                tbl = instance_video.searchOperation("select * from Booking where Movie_ID=" + Convert.ToInt32(tblData.Rows[x]["Movie_ID"].ToString()) + "");

                if (tbl.Rows.Count > cunt)
                {
                    Name = tblData.Rows[x]["Name"].ToString();
                    cunt = tbl.Rows.Count;
                }

            }
            MessageBox.Show("Best Movie of the Store is " + Name);



        }
        // for feteching best customer from the record (database)
        private void bestcus_Click(object sender, EventArgs e)
        {

            DataTable tblData = new DataTable();
            tblData = instance_video.searchOperation("select * from Customer");
            int x = 0, y = 0, cunt = 0;
            String Name = "";
            for (x = 0; x < tblData.Rows.Count; x++)
            {
                DataTable tbl = new DataTable();
                tbl = instance_video.searchOperation("select * from Booking where Customer_ID=" + Convert.ToInt32(tblData.Rows[x]["Customer_ID"].ToString()) + "");

                if (tbl.Rows.Count > cunt)
                {
                    Name = tblData.Rows[x]["Name"].ToString();
                    cunt = tbl.Rows.Count;
                }

            }
            MessageBox.Show("Favourit customer of the Store is " + Name);

        }
    }
}
