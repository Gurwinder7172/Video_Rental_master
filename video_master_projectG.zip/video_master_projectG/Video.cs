﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace video_master_projectG
{
   public class Video : Sqlconnection
    {
        // get the query store the value and then return the true
        public Boolean Insert_Video(String insert) {
            SqlOperation(insert);
            return true;
        }

        // get the query delete the value and then return the true
        public Boolean delete_Video(String delete,int _Id)
        {
            DataTable tbl = new DataTable();
            tbl = searchOperation("select * from Booking where Movie_ID=" + _Id + " and EndDate='Book'");
            if (tbl.Rows.Count == 0)
            {


                SqlOperation(delete);
                return true;
            }
            else {
                return false;
            }
        }

        //this method is used to generate the cost of the video 
        public int generateCost(int MovieYear) {
            //dislay the cost of the price of the video after adding the year of the video
            DateTime dateNow = DateTime.Now;

            int Currentyear = dateNow.Year;
            int cost = 0;

            int diffYear = Currentyear - MovieYear;
            // MessageBox.Show(diff.ToString());
            if (diffYear >= 5)
            {
                cost=2;
            }
            else if (diffYear >= 0 && diffYear < 5)
            {
                 cost = 5;
            }
            return cost;
        }


        // get the query to update the value and then return the true
        public Boolean Update_Video(String Update)
        {
            SqlOperation(Update);
            return true;
        }

    }
}
