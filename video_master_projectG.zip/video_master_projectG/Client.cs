﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace video_master_projectG
{
  public  class Client : Sqlconnection
    {
        //boolean operation to add the data to the database 
        public Boolean add_Customer(String Name,String Email,String city) {
            String Insert = "insert into Customer values('" + Name+"','"+Email+"','"+city+"')";
            SqlOperation(Insert);
            return true;
        }

        //delete the client 
        public Boolean delete_Customer(int Cust_Id) {
            DataTable tbl = new DataTable();

            tbl = searchOperation("select * from Booking where  Customer_ID=" + Cust_Id + " and EndDate='Book'");
            if (tbl.Rows.Count == 0)
            {
                String delete = "delete from Customer where Customer_ID=" + Cust_Id + "";
                SqlOperation(delete);
                return true;
            } else{
                return false;
            }
        }

        //boolean operation to update the data to the database 
        public Boolean updtae_Customer(int cust_ID,String Name, String Email, String city)
        {
            String update = "update Customer set Name='" + Name + "',Email='" + Email + "',city='" + city + "'  where Customer_ID=" + cust_ID + ""; ;
            SqlOperation(update);
            return true;
        }



    }
}
